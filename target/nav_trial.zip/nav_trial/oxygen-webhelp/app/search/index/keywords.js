var keywords=[{w:"Context",p:["p0"]},{w:"Sensitive",p:["p0"]},{w:"Help",p:["p0"]},{w:"Distribution",p:["p1"]},{w:"List",p:["p1"]},{w:"Feedback",p:["p2"]},{w:"Guide",p:["p3"]},{w:"Front",p:["p4"]},{w:"Page",p:["p4"]},{w:"Quality",p:["p5"]},{w:"Control",p:["p5"]},{w:"Active",p:["p6"]},{w:"Transducers",p:["p6"]},{w:"Contents",p:["p7"]},{w:"Pneumatic",p:["p8"]},{w:"Platforms",p:["p8"]},{w:"Shaft",p:["p9"]},{w:"Rates",p:["p9"]},{w:"Tarpauline",p:["p10"]},{w:"Regions",p:["p11"]},{w:"Welcome",p:["p12"]},{w:"What\'s",p:["p13"]},{w:"New",p:["p13"]}];
var ph={};
ph["p0"]=[0, 1, 2];
ph["p1"]=[3, 4];
ph["p2"]=[5];
ph["p3"]=[6];
ph["p4"]=[7, 8];
ph["p5"]=[9, 10];
ph["p6"]=[11, 12];
ph["p7"]=[13];
ph["p8"]=[14, 15];
ph["p9"]=[16, 17];
ph["p10"]=[18];
ph["p12"]=[20];
ph["p11"]=[19];
ph["p13"]=[21, 22];
var keywordsInfo = {
    keywords: keywords,
    ph: ph
}
