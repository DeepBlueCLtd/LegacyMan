/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
var linkToParent = {7:-1,9:-1,11:-1,10:-1,12:-1,8:-1,6:-1};
