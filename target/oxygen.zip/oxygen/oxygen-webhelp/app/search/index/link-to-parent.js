/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
var linkToParent = {23:-1,17:-1,93:-1,40:-1,42:-1};
